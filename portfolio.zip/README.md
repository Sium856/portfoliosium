# Jahidul Islam Sium — Personal Portfolio Website
CSE Undergraduate at Daffodil International University (DIU)
Focus: Competitive Programming, Problem Solving & AI Ethics Research

---

## 🚀 Quick Start (Local)
1. Unzip this folder.
2. Double-click `index.html` to open the portfolio in any web browser. No installation or build steps required!

---

## 📸 Adding Your Profile Photo
- Place your photo file into this folder and name it `profile.jpg`.
- Refresh `index.html`, and your photo will appear automatically in the glowing circular frame.
- If no `profile.jpg` is present, the website automatically falls back to the clean monogram avatar (`profile-placeholder.svg`).

---

## 🌐 Deploy to Netlify (10 Seconds)
1. Go to [netlify.com](https://www.netlify.com/) and log in.
2. Drag and drop this unzipped folder into the Netlify Sites dashboard.
3. Your portfolio is live with a custom HTTPS URL instantly!

## 🌐 Deploy to Vercel
1. Push this folder to a GitHub repository.
2. Go to [vercel.com](https://vercel.com/) and click **Add New Project**.
3. Import your repository, leave build command empty (static HTML), and click **Deploy**.

---

## 📄 Customizing Your Resume
- `resume.html` is provided as an offline-first printable resume.
- If you have an official PDF resume (e.g. `resume.pdf`), place it in this folder and update `href="resume.html"` to `href="resume.pdf"` in `index.html`.
